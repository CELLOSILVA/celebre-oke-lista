import { useState, useEffect } from 'react';

const STORAGE_KEY = 'celebre-oke-favoritos';

export function useFavoritos() {
  const [favoritos, setFavoritos] = useState<Set<string>>(new Set());
  const [isLoaded, setIsLoaded] = useState(false);

  // Carregar favoritos do localStorage ao montar
  useEffect(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        setFavoritos(new Set(JSON.parse(stored)));
      }
    } catch (error) {
      console.error('Erro ao carregar favoritos:', error);
    }
    setIsLoaded(true);
  }, []);

  // Salvar favoritos no localStorage quando mudar
  useEffect(() => {
    if (isLoaded) {
      try {
        localStorage.setItem(STORAGE_KEY, JSON.stringify(Array.from(favoritos)));
      } catch (error) {
        console.error('Erro ao salvar favoritos:', error);
      }
    }
  }, [favoritos, isLoaded]);

  const toggleFavorito = (musicaId: string) => {
    setFavoritos(prev => {
      const newSet = new Set(prev);
      if (newSet.has(musicaId)) {
        newSet.delete(musicaId);
      } else {
        newSet.add(musicaId);
      }
      return newSet;
    });
  };

  const isFavorito = (musicaId: string) => favoritos.has(musicaId);

  const getFavoritosList = () => Array.from(favoritos);

  return {
    favoritos,
    toggleFavorito,
    isFavorito,
    getFavoritosList,
    isLoaded,
  };
}
