import { useState, useMemo } from 'react';
import { Search, Music, Mic2, Heart, Copy, Check } from 'lucide-react';
import { toast } from 'sonner';
import { musicasData } from '@/lib/musicas';
import { useFavoritos } from '@/hooks/useFavoritos';

export default function Home() {
  const [searchTerm, setSearchTerm] = useState('');
  const [selectedGenre, setSelectedGenre] = useState('TODOS');
  const [displayCount, setDisplayCount] = useState(100);
  const [showFavoritesOnly, setShowFavoritesOnly] = useState(false);
  const [showRacionais, setShowRacionais] = useState(false);
  const [copiedToClipboard, setCopiedToClipboard] = useState(false);
  const [showSugestoes, setShowSugestoes] = useState(false);
  const [filterIdioma, setFilterIdioma] = useState('TODOS');
  const { favoritos, toggleFavorito, isFavorito, isLoaded } = useFavoritos();

  const artistasInternacionais = new Set([
    'Beatles', 'Abba', 'Queen', 'Pink Floyd', 'Michael Jackson', 'Madonna', 'Elvis',
    'Rolling Stones', 'David Bowie', 'Led Zeppelin', 'Roxette', 'Cher', 'Tina Turner',
    'Whitney Houston', 'Mariah Carey', 'Britney Spears', 'Christina Aguilera', 'Eminem',
    'Drake', 'Bad Bunny', 'The Weeknd', 'Dua Lipa', 'Ariana Grande', 'Billie Eilish',
    'Taylor Swift', 'Adele', 'Ed Sheeran', 'Coldplay', 'Imagine Dragons', 'OneRepublic',
    'Maroon 5', 'The Black Eyed Peas', 'Lady Gaga', 'Katy Perry', 'Rihanna', 'Beyonce',
    'Justin Bieber', 'Nicki Minaj', 'Cardi B', 'Lil Nas X', 'Post Malone', 'Travis Scott',
    'Backstreet Boys', 'NSYNC', 'Spice Girls', 'Westlife', 'Wham', 'A-Ha', 'A-Teens',
    'Ace of Base', '3 Doors Down', '4 Non Blondes', '5 Seconds Of Summer', '10,000 Maniacs',
    'Aerosmith', 'Black Eyed Peas', 'Backstreet Boys & Shania Twain'
  ]);

  // Função para verificar se é artista internacional (case-insensitive)
  const isInternacionalArtista = (cantor: string) => {
    const cantorUpper = cantor.toUpperCase();
    const artistasArray = Array.from(artistasInternacionais);
    for (let i = 0; i < artistasArray.length; i++) {
      const artist = artistasArray[i];
      if (cantorUpper === artist.toUpperCase()) return true;
      if (cantorUpper.includes(artist.toUpperCase())) return true;
    }
    return false;
  };

  // Gerar sugestoes inteligentes
  const sugestoes = useMemo(() => {
    if (!searchTerm.trim() || searchTerm.length < 2) return [];
    
    const term = searchTerm.toLowerCase().trim();
    const sugestoesSet = new Set();
    
    musicasData.forEach(m => {
      if (sugestoesSet.size >= 8) return;
      
      const cantor = m.c.toLowerCase();
      const titulo = m.t.toLowerCase();
      
      if (cantor.includes(term) && !sugestoesSet.has(m.c)) {
        sugestoesSet.add(m.c);
      }
      if (titulo.includes(term) && !sugestoesSet.has(m.t)) {
        sugestoesSet.add(m.t);
      }
    });
    
    return Array.from(sugestoesSet).slice(0, 8);
  }, [searchTerm]);

  // Funcao para exportar favoritos para a area de transferencia
  const exportarFavoritos = () => {
    if (favoritos.size === 0) {
      toast.error('Voce nao tem musicas favoritas!');
      return;
    }

    const musicasFavoritas = musicasData.filter(m => favoritos.has(m.id));
    const listaExportacao = musicasFavoritas
      .map(m => `${m.id} - ${m.c} - ${m.t}`)
      .join('\n');

    navigator.clipboard.writeText(listaExportacao).then(() => {
      setCopiedToClipboard(true);
      toast.success(`${favoritos.size} musicas copiadas para a area de transferencia!`);
      setTimeout(() => setCopiedToClipboard(false), 2000);
    }).catch(() => {
      toast.error('Erro ao copiar para a area de transferencia');
    });
  };

  // Filtrar apenas musicas do Racionais MCs
  const racionaisMcs = useMemo(() => {
    return musicasData.filter(m => m.c === 'RACIONAIS');
  }, []);

  // Filtrar músicas baseado em busca, gênero e favoritos
  const filteredMusicas = useMemo(() => {
    let result = musicasData;

    if (showRacionais) {
      result = result.filter(m => m.c === 'RACIONAIS');
    } else {
      if (showFavoritesOnly) {
        result = result.filter(m => favoritos.has(m.id));
      }

      if (selectedGenre !== 'TODOS') {
        result = result.filter(m => m.g === selectedGenre);
      }

      if (searchTerm.trim()) {
        const term = searchTerm.toLowerCase().trim();
        result = result.filter(m => {
          const titulo = m.t.toLowerCase();
          const cantor = m.c.toLowerCase();
          return titulo.includes(term) || cantor.includes(term);
        });
      }

      if (filterIdioma !== 'TODOS') {
        result = result.filter(m => {
          const isInternacional = isInternacionalArtista(m.c);
          if (filterIdioma === 'INTERNACIONAL') return isInternacional;
          if (filterIdioma === 'NACIONAL') return !isInternacional;
          return true;
        });
      }
    }

    return result;
  }, [searchTerm, selectedGenre, showFavoritesOnly, favoritos, showRacionais, filterIdioma, artistasInternacionais, isInternacionalArtista]);

  const totalFavoritos = favoritos.size;

  return (
    <div className="min-h-screen bg-gradient-to-b from-slate-900 via-purple-900 to-slate-900">
      {/* Header Neon */}
      <header className="sticky top-0 z-50 bg-black/80 backdrop-blur-md border-b border-pink-500/30 shadow-2xl">
        <div className="max-w-7xl mx-auto px-4 py-6">
          {/* Logo e Título */}
          <div className="flex items-center justify-center mb-6 gap-3">
            <div className="relative">
              <Mic2 className="w-10 h-10 text-cyan-400 drop-shadow-lg" style={{
                textShadow: '0 0 20px rgba(34, 211, 238, 0.8), 0 0 40px rgba(236, 72, 153, 0.6)',
                filter: 'drop-shadow(0 0 10px rgba(34, 211, 238, 0.8))'
              }} />
            </div>
            <h1 className="text-4xl font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 via-pink-500 to-purple-500" style={{
              textShadow: '0 0 30px rgba(34, 211, 238, 0.6), 0 0 60px rgba(236, 72, 153, 0.4), 0 0 20px rgba(168, 85, 247, 0.3)',
              letterSpacing: '0.15em'
            }}>
              CELEBRE-OKE
            </h1>
          </div>

          <p className="text-center text-cyan-300/70 text-sm font-semibold tracking-[2px] mb-6 uppercase">
            Catálogo Digital • {filteredMusicas.length.toLocaleString()} Músicas
            {totalFavoritos > 0 && <span className="text-pink-400 ml-2">❤️ {totalFavoritos} Favoritos</span>}
          </p>

          {/* Barra de Busca */}
          <div className="relative">
            <Search className="absolute left-4 top-1/2 transform -translate-y-1/2 w-5 h-5 text-cyan-400/50" />
            <input
              type="text"
              placeholder="Buscar música ou cantor..."
              value={searchTerm}
              onChange={(e) => {
                setSearchTerm(e.target.value);
                setDisplayCount(100);
                setShowSugestoes(true);
              }}
              onFocus={() => setShowSugestoes(true)}
              onBlur={() => setTimeout(() => setShowSugestoes(false), 200)}
              className="w-full pl-12 pr-4 py-3 bg-gradient-to-r from-slate-800 to-slate-900 border-2 border-cyan-500/50 rounded-full text-white placeholder-cyan-300/40 focus:outline-none focus:border-pink-500 focus:ring-2 focus:ring-pink-500/30 transition-all duration-300 font-medium"
            />
            {showSugestoes && sugestoes.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-slate-800/95 border border-cyan-500/30 rounded-lg shadow-2xl shadow-cyan-500/20 backdrop-blur-md z-50">
                {sugestoes.map((sugestao, idx) => (
                  <button
                    key={idx}
                    onClick={() => {
                      setSearchTerm(String(sugestao));
                      setShowSugestoes(false);
                    }}
                    className="w-full px-4 py-2 text-left text-cyan-300 hover:bg-pink-500/20 hover:text-pink-400 transition-colors duration-200 border-b border-cyan-500/10 last:border-b-0 text-sm font-medium"
                  >
                    {String(sugestao)}
                  </button>
                ))}
              </div>
            )}
          </div>
        </div>
      </header>

      {/* Botões de Navegação */}
      <div className="sticky top-[140px] z-40 bg-black/60 backdrop-blur-md border-b border-purple-500/20 py-4 px-4">
        <div className="max-w-7xl mx-auto flex gap-4 justify-center">
          {/* Botão TODOS */}
          <button
            onClick={() => {
              setSelectedGenre('TODOS');
              setShowFavoritesOnly(false);
              setShowRacionais(false);
              setDisplayCount(100);
            }}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 ${
              !showFavoritesOnly && !showRacionais && selectedGenre === 'TODOS'
                ? 'bg-gradient-to-r from-cyan-500 to-pink-500 text-white shadow-lg shadow-pink-500/50'
                : 'bg-slate-800/50 text-cyan-300/70 border border-cyan-500/30 hover:border-pink-500/50 hover:text-pink-400'
            }`}
          >
            TODOS
          </button>

          {/* Botão Racionais MCs */}
          <button
            onClick={() => {
              setShowRacionais(!showRacionais);
              setShowFavoritesOnly(false);
              setDisplayCount(100);
            }}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 ${
              showRacionais
                ? 'bg-gradient-to-r from-purple-500 to-pink-500 text-white shadow-lg shadow-purple-500/50'
                : 'bg-slate-800/50 text-purple-300/70 border border-purple-500/30 hover:border-purple-500/50 hover:text-purple-400'
            }`}
          >
            RACIONAIS MCs ({racionaisMcs.length})
          </button>

          {/* Botão Favoritos */}
          <button
            onClick={() => {
              setShowFavoritesOnly(!showFavoritesOnly);
              setShowRacionais(false);
              setDisplayCount(100);
            }}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 flex items-center gap-2 ${
              showFavoritesOnly
                ? 'bg-gradient-to-r from-red-500 to-pink-500 text-white shadow-lg shadow-pink-500/50'
                : 'bg-slate-800/50 text-pink-300/70 border border-pink-500/30 hover:border-pink-500/50 hover:text-pink-400'
            }`}
          >
            <Heart className={`w-4 h-4 ${showFavoritesOnly ? 'fill-current' : ''}`} />
            MEUS FAVORITOS {totalFavoritos > 0 && `(${totalFavoritos})`}
          </button>

          <div className="h-8 w-px bg-cyan-500/20"></div>

          <button
            onClick={() => {
              setFilterIdioma(filterIdioma === 'NACIONAL' ? 'TODOS' : 'NACIONAL');
              setDisplayCount(100);
            }}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 ${
              filterIdioma === 'NACIONAL'
                ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg shadow-green-500/50'
                : 'bg-slate-800/50 text-green-300/70 border border-green-500/30 hover:border-green-500/50 hover:text-green-400'
            }`}
          >
            NACIONAL
          </button>

          <button
            onClick={() => {
              setFilterIdioma(filterIdioma === 'INTERNACIONAL' ? 'TODOS' : 'INTERNACIONAL');
              setDisplayCount(100);
            }}
            className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 ${
              filterIdioma === 'INTERNACIONAL'
                ? 'bg-gradient-to-r from-blue-500 to-cyan-500 text-white shadow-lg shadow-blue-500/50'
                : 'bg-slate-800/50 text-blue-300/70 border border-blue-500/30 hover:border-blue-500/50 hover:text-blue-400'
            }`}
          >
            INTERNACIONAL
          </button>

          {totalFavoritos > 0 && (
            <button
              onClick={exportarFavoritos}
              className={`px-6 py-2 rounded-full font-bold text-sm transition-all duration-300 flex items-center gap-2 ${
                copiedToClipboard
                  ? 'bg-gradient-to-r from-green-500 to-emerald-500 text-white shadow-lg shadow-green-500/50'
                  : 'bg-slate-800/50 text-cyan-300/70 border border-cyan-500/30 hover:border-cyan-500/50 hover:text-cyan-400'
              }`}
            >
              {copiedToClipboard ? (
                <>
                  <Check className="w-4 h-4" />
                  COPIADO!
                </>
              ) : (
                <>
                  <Copy className="w-4 h-4" />
                  EXPORTAR
                </>
              )}
            </button>
          )}
        </div>
      </div>

      {/* Lista de Músicas */}
      <main className="max-w-7xl mx-auto px-4 py-8">
        {!isLoaded ? (
          <div className="text-center py-16">
            <div className="animate-spin">
              <Music className="w-16 h-16 text-purple-500/30 mx-auto" />
            </div>
            <p className="text-cyan-300/50 text-lg font-semibold mt-4">Carregando...</p>
          </div>
        ) : filteredMusicas.length === 0 ? (
          <div className="text-center py-16">
            <Music className="w-16 h-16 text-purple-500/30 mx-auto mb-4" />
            <p className="text-cyan-300/50 text-lg font-semibold">
              {showFavoritesOnly ? 'Nenhum favorito adicionado ainda' : 'Nenhuma música encontrada'}
            </p>
          </div>
        ) : (
          <>
            <div className="grid gap-3">
              {filteredMusicas.slice(0, displayCount).map((musica, idx) => (
                <div
                  key={`${musica.id}-${idx}`}
                  className="group bg-gradient-to-r from-slate-800/40 to-slate-900/40 border border-cyan-500/20 hover:border-pink-500/50 rounded-xl p-4 flex items-center justify-between transition-all duration-300 hover:shadow-lg hover:shadow-pink-500/20 backdrop-blur-sm"
                >
                  <div className="flex-1 min-w-0">
                    <h3 translate="no" className="text-white font-black text-sm uppercase tracking-wide group-hover:text-transparent group-hover:bg-clip-text group-hover:bg-gradient-to-r group-hover:from-cyan-400 group-hover:to-pink-500 transition-all duration-300 truncate">
                      {musica.t}
                    </h3>
                    <p translate="no" className="text-cyan-300/60 text-xs mt-1 font-medium italic truncate">
                      {musica.c}
                    </p>
                  </div>

                  <div className="ml-4 flex items-center gap-3">
                    {/* Botão Favorito */}
                    <button
                      onClick={() => toggleFavorito(musica.id)}
                      className="transition-all duration-300 hover:scale-110"
                      title={isFavorito(musica.id) ? 'Remover de favoritos' : 'Adicionar aos favoritos'}
                    >
                      <Heart
                        className={`w-5 h-5 transition-all duration-300 ${
                          isFavorito(musica.id)
                            ? 'fill-red-500 text-red-500 drop-shadow-lg'
                            : 'text-cyan-400/50 hover:text-pink-400'
                        }`}
                      />
                    </button>

                    <div className="text-right">
                      <div className="bg-gradient-to-br from-cyan-400 to-pink-500 text-white font-black px-4 py-2 rounded-lg text-lg shadow-lg shadow-pink-500/50 border border-white/20 min-w-[60px] text-center">
                        {musica.id}
                      </div>
                      <p className="text-[9px] text-cyan-300/50 mt-1 font-bold tracking-tighter uppercase">
                        {musica.g}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>

            {/* Informações e Botão Carregar Mais */}
            <div className="mt-8 text-center">
              <p className="text-cyan-300/60 text-sm font-semibold mb-4">
                Mostrando {Math.min(displayCount, filteredMusicas.length)} de {filteredMusicas.length} músicas
              </p>

              {displayCount < filteredMusicas.length && (
                <button
                  onClick={() => setDisplayCount(prev => prev + 100)}
                  className="px-8 py-3 bg-gradient-to-r from-cyan-500 to-pink-500 text-white font-bold rounded-full hover:shadow-lg hover:shadow-pink-500/50 transition-all duration-300 uppercase tracking-wide text-sm"
                >
                  Carregar Mais
                </button>
              )}
            </div>
          </>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-purple-500/20 bg-black/40 py-6 mt-12 text-center">
        <p className="text-cyan-300/50 text-xs font-semibold tracking-widest uppercase">
          CELEBRE-OKE © 2024 • Catálogo Digital de Karaokê
        </p>
      </footer>

      <style>{`
        .no-scrollbar::-webkit-scrollbar {
          display: none;
        }
        .no-scrollbar {
          -ms-overflow-style: none;
          scrollbar-width: none;
        }
      `}</style>
    </div>
  );
}
