# 🚀 Guia de Deploy CELEBRE-OKE no Netlify

## Opção 1: Deploy Direto (Mais Simples - Recomendado)

### Passo 1: Preparar o Projeto
O projeto está pronto para deploy. Você pode fazer upload direto da pasta `dist/public` para o Netlify.

### Passo 2: Acessar Netlify
1. Acesse [netlify.com](https://netlify.com)
2. Clique em **"Sign up"** (ou faça login se já tem conta)
3. Escolha **"Sign up with GitHub"** (mais fácil)

### Passo 3: Deploy via Drag & Drop (Mais Rápido)
1. Após fazer login, clique em **"Add new site"** → **"Deploy manually"**
2. Arraste a pasta `dist/public` para a área de upload
3. Pronto! Seu site estará online em segundos com um link como: `https://seu-site-aleatorio.netlify.app`

---

## Opção 2: Deploy via GitHub (Mais Profissional)

### Passo 1: Criar Repositório no GitHub
1. Acesse [github.com](https://github.com)
2. Clique em **"New repository"**
3. Nome: `celebre-oke-catalogo`
4. Descrição: "Catálogo digital de karaokê com 10.522 músicas"
5. Escolha **"Public"** (para que o Netlify possa acessar)
6. Clique em **"Create repository"**

### Passo 2: Fazer Push do Código
```bash
cd /home/ubuntu/celebre-oke-catalogo

# Inicializar git (se ainda não foi feito)
git init
git add .
git commit -m "Initial commit: CELEBRE-OKE catálogo com favoritos"

# Adicionar remote (substitua SEU_USUARIO e SEU_REPO)
git remote add origin https://github.com/SEU_USUARIO/celebre-oke-catalogo.git
git branch -M main
git push -u origin main
```

### Passo 3: Conectar Netlify ao GitHub
1. Acesse [netlify.com](https://netlify.com) e faça login
2. Clique em **"Add new site"** → **"Import an existing project"**
3. Escolha **"GitHub"** e autorize o acesso
4. Selecione o repositório `celebre-oke-catalogo`
5. Configure as opções de build:
   - **Build command**: `pnpm build`
   - **Publish directory**: `dist/public`
6. Clique em **"Deploy site"**

---

## Opção 3: Deploy via Vercel (Alternativa)

### Passo 1: Acessar Vercel
1. Acesse [vercel.com](https://vercel.com)
2. Clique em **"Sign up"** → **"Continue with GitHub"**

### Passo 2: Importar Projeto
1. Clique em **"New Project"**
2. Selecione o repositório `celebre-oke-catalogo`
3. Vercel detectará automaticamente que é um projeto Vite
4. Configure:
   - **Framework Preset**: `Vite`
   - **Build Command**: `pnpm build`
   - **Output Directory**: `dist/public`
5. Clique em **"Deploy"**

---

## ✅ Após o Deploy

### Seu Link Público
Você receberá um link como:
- Netlify: `https://seu-site.netlify.app`
- Vercel: `https://seu-site.vercel.app`

### Gerar QR-Code
1. Acesse [qr-code-generator.com](https://www.qr-code-generator.com)
2. Cole seu link público
3. Baixe a imagem do QR-Code
4. Compartilhe com seus clientes!

### Domínio Personalizado (Opcional)
- Netlify: Settings → Domain management → Add custom domain
- Vercel: Settings → Domains → Add

---

## 🔧 Troubleshooting

### "Build failed"
- Certifique-se de que `pnpm install` foi executado
- Verifique se o arquivo `dist/public/index.html` existe

### "Página em branco"
- Limpe o cache do navegador (Ctrl+Shift+Delete)
- Verifique se o arquivo `dist/public/index.html` tem conteúdo

### "Estilos não carregam"
- Verifique se os arquivos CSS estão em `dist/public/assets/`
- Aguarde alguns minutos para o CDN cachear os arquivos

---

## 📱 Teste no Mobile
Após o deploy, acesse o link em um celular para garantir que tudo funciona corretamente offline.

---

**Dúvidas?** Consulte a documentação oficial:
- [Netlify Docs](https://docs.netlify.com)
- [Vercel Docs](https://vercel.com/docs)
